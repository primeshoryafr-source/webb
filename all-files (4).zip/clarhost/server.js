const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const root = __dirname;
const port = Number(process.env.PORT || 3000);
loadEnv();

const isProduction = process.env.NODE_ENV === 'production';
const demoMode = process.env.DEMO_MODE === 'true';
const razorpayMode = String(process.env.RAZORPAY_MODE || 'live').toLowerCase();
const appSecret = process.env.APP_SECRET || crypto.randomBytes(32).toString('hex');
const dataFile = process.env.DATA_FILE || path.join(root, 'data', 'store.json');
const panelUrl = (process.env.PTERODACTYL_URL || '').replace(/\/$/, '');
const sessions = new Map();
const adminLoginAttempts = new Map();

const gameTemplates = {
  minecraft: { gameName: 'Minecraft', image: 'ghcr.io/pterodactyl/yolks:java_21', startup: 'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}', environment: { SERVER_JARFILE: 'server.jar', MINECRAFT_VERSION: 'latest', BUILD_NUMBER: 'latest' } },
  rust: { gameName: 'Rust' }, cs2: { gameName: 'Counter-Strike 2' }, ark: { gameName: 'ARK: Survival' }, palworld: { gameName: 'Palworld' }, valheim: { gameName: 'Valheim' }
};

const planDefinitions = {
  minecraft: [['2gb','Starter',199,2048,10240,20,100],['4gb','Standard',399,4096,20480,40,150],['8gb','Pro',699,8192,40960,80,250],['16gb','Community',1299,16384,81920,160,400]],
  rust: [['6gb','Starter',599,6144,30720,40,200],['8gb','Standard',749,8192,40960,60,250],['12gb','Pro',999,12288,61440,100,350],['16gb','Community',1399,16384,81920,150,450]],
  cs2: [['4gb','Starter',549,4096,20480,12,180],['6gb','Competitive',699,6144,30720,20,250],['8gb','Pro',849,8192,40960,32,350],['12gb','Tournament',1199,12288,61440,64,500]],
  ark: [['8gb','Starter',749,8192,40960,20,250],['12gb','Standard',999,12288,61440,40,350],['16gb','Cluster',1299,16384,81920,70,450],['24gb','Ascendant',1799,24576,122880,100,600]],
  palworld: [['8gb','Starter',699,8192,30720,12,250],['12gb','Standard',949,12288,51200,24,350],['16gb','Pro',1199,16384,71680,32,450],['24gb','Guild',1699,24576,102400,48,600]],
  valheim: [['2gb','Starter',199,2048,10240,5,100],['4gb','Standard',349,4096,20480,10,150],['8gb','Clan',599,8192,40960,20,250],['12gb','Community',849,12288,61440,40,350]]
};

const catalog = Object.fromEntries(Object.entries(planDefinitions).flatMap(([gameId, plans]) => plans.map(([slug, planName, price, memory, disk, slots, cpu]) => {
  const template = gameTemplates[gameId];
  const id = `${gameId}-${slug}`;
  return [id, { id, gameId, gameName: template.gameName, name: `${template.gameName} ${planName}`, planName, price, memory, disk, slots, cpu, image: template.image, startup: template.startup, environment: template.environment }];
})));

const mime = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'application/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.webp': 'image/webp' };
const publicFiles = new Set(['index.html', 'styles.css', 'banners.css', 'plans.css', 'motion.css', 'app.js', 'dashboard.html', 'dashboard.css', 'dashboard-responsive.css', 'dashboard.js', 'admin.html', 'admin.css', 'admin.js', 'assets/banners/minecraft.webp', 'assets/banners/rust.webp', 'assets/banners/cs2.webp', 'assets/banners/ark.webp', 'assets/banners/palworld.webp', 'assets/banners/valheim.webp']);
let store = readStore();

function loadEnv() {
  try {
    for (const line of fs.readFileSync(path.join(root, '.env'), 'utf8').split(/\r?\n/)) {
      const match = line.match(/^([A-Z0-9_]+)=(.*)$/);
      if (match && !process.env[match[1]]) process.env[match[1]] = match[2].replace(/^['"]|['"]$/g, '');
    }
  } catch {}
}

function readStore() {
  try { return JSON.parse(fs.readFileSync(dataFile, 'utf8')); }
  catch { return { users: {}, orders: {}, servers: {} }; }
}

function saveStore() {
  fs.mkdirSync(path.dirname(dataFile), { recursive: true });
  const temp = `${dataFile}.${process.pid}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(store, null, 2), { mode: 0o600 });
  fs.renameSync(temp, dataFile);
}

function json(res, status, data, extraHeaders = {}) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', ...extraHeaders });
  res.end(JSON.stringify(data));
}

function readBody(req, raw = false) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', chunk => {
      size += chunk.length;
      if (size > 250000) { reject(new Error('Request too large')); req.destroy(); return; }
      chunks.push(chunk);
    });
    req.on('end', () => {
      const buffer = Buffer.concat(chunks);
      if (raw) return resolve(buffer);
      try { resolve(JSON.parse(buffer.toString('utf8') || '{}')); }
      catch { reject(new Error('Invalid JSON')); }
    });
    req.on('error', reject);
  });
}

function calculate(items) {
  if (!Array.isArray(items) || !items.length) throw new Error('Cart is empty');
  const unique = [...new Set(items)];
  const selected = unique.map(id => ({ id, ...catalog[id] })).filter(item => item.name);
  if (selected.length !== unique.length) throw new Error('Invalid product');
  const subtotal = selected.reduce((sum, item) => sum + item.price, 0);
  return { selected, subtotal, tax: Math.round(subtotal * 0.18), total: Math.round(subtotal * 1.18) };
}

function normalizeEmail(value) { return String(value || '').trim().toLowerCase(); }
function safeEqual(a, b) {
  const left = Buffer.from(String(a || ''));
  const right = Buffer.from(String(b || ''));
  return left.length === right.length && crypto.timingSafeEqual(left, right);
}

function setupToken(order) {
  const token = crypto.randomBytes(32).toString('base64url');
  order.setupTokenHash = crypto.createHash('sha256').update(token).digest('hex');
  return token;
}

function validateCustomer(customer) {
  const name = String(customer?.name || '').trim().slice(0, 80);
  const email = normalizeEmail(customer?.email);
  const password = String(customer?.password || '');
  const contact = String(customer?.contact || '').replace(/[^0-9+]/g, '').slice(0, 16);
  if (name.length < 2) throw new Error('Please enter your full name');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('Please enter a valid email');
  if (password.length < 8 || password.length > 128) throw new Error('Password must be 8–128 characters');
  if (!/^\+?[0-9]{10,15}$/.test(contact)) throw new Error('Please enter a valid mobile number');
  return { name, email, contact, password, region: String(customer?.region || 'delhi').slice(0, 30) };
}

function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

function verifyPassword(password, saved) {
  const [salt, expected] = String(saved || '').split(':');
  if (!salt || !expected) return false;
  return safeEqual(hashPassword(password, salt), saved);
}

function encryptSecret(value) {
  const iv = crypto.randomBytes(12);
  const key = crypto.createHash('sha256').update(appSecret).digest();
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(value, 'utf8'), cipher.final()]);
  return [iv.toString('base64url'), cipher.getAuthTag().toString('base64url'), encrypted.toString('base64url')].join('.');
}

function decryptSecret(value) {
  const [iv, tag, encrypted] = String(value || '').split('.');
  const key = crypto.createHash('sha256').update(appSecret).digest();
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(iv, 'base64url'));
  decipher.setAuthTag(Buffer.from(tag, 'base64url'));
  return Buffer.concat([decipher.update(Buffer.from(encrypted, 'base64url')), decipher.final()]).toString('utf8');
}

function parseCookies(req) {
  return Object.fromEntries(String(req.headers.cookie || '').split(';').map(v => v.trim().split('=').map(decodeURIComponent)).filter(v => v.length === 2));
}

function createSession(email, role = 'customer') {
  const id = crypto.randomBytes(32).toString('base64url');
  const csrf = crypto.randomBytes(24).toString('base64url');
  sessions.set(id, { email, role, csrf, expires: Date.now() + 7 * 86400000 });
  return { id, csrf };
}

function getSession(req) {
  const id = parseCookies(req).clar_session;
  const session = sessions.get(id);
  if (!session || session.expires < Date.now()) { if (id) sessions.delete(id); return null; }
  return { id, ...session };
}

function sessionCookie(id, clear = false) {
  return `clar_session=${clear ? '' : encodeURIComponent(id)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${clear ? 0 : 604800}${isProduction ? '; Secure' : ''}`;
}

function requireSession(req, res) {
  const session = getSession(req);
  if (!session) { json(res, 401, { error: 'Please log in' }); return null; }
  return session;
}

function requireAdmin(req, res) {
  const session = getSession(req);
  if (!session || session.role !== 'admin') { json(res, 401, { error: 'Admin login required' }); return null; }
  return session;
}

function adminLoginAllowed(req) {
  const key = String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
  const now = Date.now();
  const entry = adminLoginAttempts.get(key) || { count: 0, reset: now + 15 * 60000 };
  if (entry.reset < now) { entry.count = 0; entry.reset = now + 15 * 60000; }
  entry.count += 1;
  adminLoginAttempts.set(key, entry);
  return entry.count <= 5;
}

function adminCredentials() {
  return {
    email: normalizeEmail(process.env.ADMIN_EMAIL || (demoMode ? 'admin@clarhost.demo' : '')),
    password: process.env.ADMIN_PASSWORD || (demoMode ? 'ClarHostDemo123!' : '')
  };
}

function requireCsrf(req, res, session) {
  if (!safeEqual(req.headers['x-csrf-token'], session.csrf)) { json(res, 403, { error: 'Security token expired. Refresh and try again.' }); return false; }
  return true;
}

function checkOrigin(req) {
  const origin = req.headers.origin;
  if (!origin) return true;
  try { return new URL(origin).host === req.headers.host; } catch { return false; }
}

async function razorpay(pathname, options = {}) {
  if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) throw new Error('Razorpay keys are not configured');
  const auth = Buffer.from(`${process.env.RAZORPAY_KEY_ID}:${process.env.RAZORPAY_KEY_SECRET}`).toString('base64');
  const response = await fetch(`https://api.razorpay.com/v1${pathname}`, {
    ...options,
    headers: { Authorization: `Basic ${auth}`, 'Content-Type': 'application/json', ...(options.headers || {}) }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data?.error?.description || 'Payment provider rejected the request');
  return data;
}

function razorpayConfigError() {
  if (!['test', 'live'].includes(razorpayMode)) return 'RAZORPAY_MODE must be test or live';
  if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) return `Razorpay ${razorpayMode} API keys are not configured`;
  if (!process.env.RAZORPAY_WEBHOOK_SECRET) return 'Razorpay webhook secret is not configured';
  const prefix = razorpayMode === 'live' ? 'rzp_live_' : 'rzp_test_';
  if (!process.env.RAZORPAY_KEY_ID.startsWith(prefix)) return `Key ID does not match Razorpay ${razorpayMode} mode`;
  return null;
}

async function createRazorpayOrder(cost, receipt) {
  return razorpay('/orders', { method: 'POST', body: JSON.stringify({ amount: cost.total * 100, currency: 'INR', receipt, notes: { brand: 'ClarHost' } }) });
}

async function confirmPayment(paymentId, expectedOrderId, expectedAmount) {
  let payment = await razorpay(`/payments/${encodeURIComponent(paymentId)}`);
  if (payment.order_id !== expectedOrderId || payment.currency !== 'INR' || payment.amount !== expectedAmount * 100) throw new Error('Payment details do not match this order');
  if (payment.status === 'authorized') payment = await razorpay(`/payments/${encodeURIComponent(paymentId)}/capture`, { method: 'POST', body: JSON.stringify({ amount: expectedAmount * 100, currency: 'INR' }) });
  if (payment.status !== 'captured') throw new Error('Payment has not been captured');
  return payment;
}

function paymentSignatureValid(orderId, paymentId, signature) {
  const expected = crypto.createHmac('sha256', process.env.RAZORPAY_KEY_SECRET || '').update(`${orderId}|${paymentId}`).digest('hex');
  return safeEqual(expected, signature);
}

async function pteroApplication(pathname, options = {}) {
  if (!panelUrl || !process.env.PTERODACTYL_API_KEY) throw new Error('Pterodactyl Application API is not configured');
  const response = await fetch(`${panelUrl}/api/application${pathname}`, {
    ...options,
    headers: { Authorization: `Bearer ${process.env.PTERODACTYL_API_KEY}`, Accept: 'Application/vnd.pterodactyl.v1+json', 'Content-Type': 'application/json', ...(options.headers || {}) }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data?.errors?.[0]?.detail || 'Pterodactyl Application API request failed');
  return data;
}

async function pteroClient(pathname, options = {}) {
  if (!panelUrl || !process.env.PTERODACTYL_CLIENT_API_KEY) throw new Error('Pterodactyl Client API is not configured');
  const response = await fetch(`${panelUrl}/api/client${pathname}`, {
    ...options,
    headers: { Authorization: `Bearer ${process.env.PTERODACTYL_CLIENT_API_KEY}`, Accept: 'Application/vnd.pterodactyl.v1+json', 'Content-Type': 'application/json', ...(options.headers || {}) }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data?.errors?.[0]?.detail || 'Pterodactyl Client API request failed');
  return data;
}

function gameConfig(id, item) {
  let overrides = {};
  try { overrides = JSON.parse(process.env.PTERODACTYL_GAME_CONFIG_JSON || '{}')[id] || {}; } catch { throw new Error('PTERODACTYL_GAME_CONFIG_JSON is invalid'); }
  const config = {
    egg: Number(overrides.egg || (id === 'minecraft' ? process.env.PTERODACTYL_EGG_ID : 0)),
    allocation: Number(overrides.allocation || process.env.PTERODACTYL_ALLOCATION_ID || 0),
    location: Number(overrides.location || process.env.PTERODACTYL_LOCATION_ID || 0),
    image: overrides.image || item.image,
    startup: overrides.startup || item.startup,
    environment: { ...(item.environment || {}), ...(overrides.environment || {}) }
  };
  if (!config.egg || (!config.allocation && !config.location) || !config.image || !config.startup) throw new Error(`${item.name} egg/location configuration is incomplete`);
  return config;
}

async function ensurePteroUser(customer, password) {
  const result = await pteroApplication(`/users?filter[email]=${encodeURIComponent(customer.email)}`);
  let user = result.data?.[0]?.attributes;
  if (user) return user;
  const names = customer.name.trim().split(/\s+/);
  const created = await pteroApplication('/users', { method: 'POST', body: JSON.stringify({
    email: customer.email,
    username: `clar_${crypto.randomBytes(5).toString('hex')}`,
    first_name: names[0] || 'ClarHost',
    last_name: names.slice(1).join(' ') || 'Customer',
    password
  }) });
  return created.attributes;
}

async function createGameServer(order, item, index, password) {
  if (demoMode) return { identifier: `demo-${crypto.randomBytes(4).toString('hex')}`, internalId: Date.now() + index };
  const pteroUser = await ensurePteroUser(order.customer, password);
  const config = gameConfig(item.gameId, item);
  const placement = config.allocation ? { allocation: { default: config.allocation } } : { deploy: { locations: [config.location], dedicated_ip: false, port_range: [] } };
  const created = await pteroApplication('/servers', { method: 'POST', body: JSON.stringify({
    name: `${item.name} · ${order.customer.name}`,
    user: pteroUser.id,
    egg: config.egg,
    docker_image: config.image,
    startup: config.startup,
    environment: config.environment,
    limits: { memory: item.memory, swap: 0, disk: item.disk, io: 500, cpu: item.cpu },
    feature_limits: { databases: 2, allocations: 1, backups: 3 },
    ...placement,
    external_id: `${order.id}-${index}`
  }) });
  return { identifier: created.attributes?.identifier, internalId: created.attributes?.id };
}

async function fulfilOrder(orderId, paymentId) {
  const order = store.orders[orderId];
  if (!order) throw new Error('Order not found');
  if (order.status === 'provisioned') return order;
  order.status = 'provisioning';
  order.paymentId = paymentId || order.paymentId;
  order.updatedAt = new Date().toISOString();
  const existingUser = store.users[order.customer.email];
  store.users[order.customer.email] = existingUser || { name: order.customer.name, email: order.customer.email, passwordHash: order.passwordHash, createdAt: new Date().toISOString() };
  saveStore();

  try {
    const password = decryptSecret(order.encryptedPassword);
    order.serverIds = order.serverIds || [];
    for (let index = 0; index < order.cost.selected.length; index++) {
      if (order.serverIds[index]) continue;
      const item = order.cost.selected[index];
      const created = await createGameServer(order, item, index, password);
      const localId = crypto.randomUUID();
      store.servers[localId] = { id: localId, owner: order.customer.email, orderId, gameId: item.gameId, planName: item.planName, name: `${item.gameName} · ${item.planName}`, identifier: created.identifier, internalId: created.internalId, memory: item.memory, disk: item.disk, slots: item.slots, cpu: item.cpu, createdAt: new Date().toISOString() };
      order.serverIds[index] = localId;
      saveStore();
    }
    order.status = 'provisioned';
    delete order.encryptedPassword;
    order.updatedAt = new Date().toISOString();
    saveStore();
    return order;
  } catch (error) {
    order.status = 'action_required';
    order.provisioningError = error.message;
    order.updatedAt = new Date().toISOString();
    saveStore();
    throw error;
  }
}

async function handleWebhook(req, res) {
  const raw = await readBody(req, true);
  const signature = req.headers['x-razorpay-signature'];
  const expected = crypto.createHmac('sha256', process.env.RAZORPAY_WEBHOOK_SECRET || '').update(raw).digest('hex');
  if (!process.env.RAZORPAY_WEBHOOK_SECRET || !safeEqual(signature, expected)) return json(res, 401, { error: 'Invalid webhook signature' });
  const event = JSON.parse(raw.toString('utf8'));
  if (event.event === 'payment.captured') {
    const payment = event.payload?.payment?.entity;
    const order = store.orders[payment?.order_id];
    if (order && payment.amount === order.cost.total * 100 && payment.currency === 'INR') {
      order.paymentId = payment.id;
      order.paymentEmail = normalizeEmail(payment.email);
      order.paymentContact = String(payment.contact || '');
      if (order.customer && order.encryptedPassword) await fulfilOrder(order.id, payment.id).catch(() => {});
      else { order.status = 'paid_profile_required'; order.updatedAt = new Date().toISOString(); saveStore(); }
    }
  }
  return json(res, 200, { received: true });
}

function ownedServer(email, localId) {
  const server = store.servers[localId];
  return server && server.owner === email ? server : null;
}

async function api(req, res, url) {
  if (req.method === 'POST' && url.pathname === '/api/webhooks/razorpay') return handleWebhook(req, res);
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method) && !checkOrigin(req)) return json(res, 403, { error: 'Origin not allowed' });

  if (req.method === 'GET' && url.pathname === '/api/health') return json(res, 200, { ok: true, demo: demoMode, razorpay: demoMode || !razorpayConfigError(), razorpayMode, panel: Boolean(panelUrl && process.env.PTERODACTYL_API_KEY), clientApi: Boolean(process.env.PTERODACTYL_CLIENT_API_KEY) });
  if (req.method === 'GET' && url.pathname === '/api/catalog') return json(res, 200, Object.values(catalog).map(({ id, gameId, gameName, planName, price, memory, disk, slots, cpu }) => ({ id, gameId, gameName, planName, price, memory, disk, slots, cpu })));

  if (req.method === 'POST' && url.pathname === '/api/payments/order') {
    try {
      if (!demoMode && razorpayConfigError()) throw new Error(razorpayConfigError());
      if (!demoMode && (!process.env.APP_SECRET || process.env.APP_SECRET.length < 32)) throw new Error('APP_SECRET must contain at least 32 characters');
      const data = await readBody(req);
      const cost = calculate(data.items);
      const receipt = `clar_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
      const providerOrder = demoMode ? { id: `demo_${crypto.randomBytes(10).toString('hex')}`, amount: cost.total * 100, currency: 'INR' } : await createRazorpayOrder(cost, receipt);
      store.orders[providerOrder.id] = {
        id: providerOrder.id,
        receipt,
        customer: null,
        cost,
        status: 'payment_pending',
        createdAt: new Date().toISOString()
      };
      saveStore();
      return json(res, 200, { mode: demoMode ? 'demo' : 'live', key_id: demoMode ? undefined : process.env.RAZORPAY_KEY_ID, order_id: providerOrder.id, amount: providerOrder.amount, currency: providerOrder.currency });
    } catch (error) { return json(res, 400, { error: error.message }); }
  }

  if (req.method === 'POST' && url.pathname === '/api/payments/verify') {
    try {
      const data = await readBody(req);
      const order = store.orders[data.razorpay_order_id];
      if (!order) return json(res, 404, { error: 'Order not found' });
      let payment = {};
      if (!(demoMode && order.id.startsWith('demo_'))) {
        if (!paymentSignatureValid(data.razorpay_order_id, data.razorpay_payment_id, data.razorpay_signature)) return json(res, 401, { error: 'Payment signature verification failed' });
        payment = await confirmPayment(data.razorpay_payment_id, order.id, order.cost.total);
      }
      order.paymentId = data.razorpay_payment_id || 'demo_payment';
      order.paymentEmail = normalizeEmail(payment.email || order.paymentEmail);
      order.paymentContact = String(payment.contact || order.paymentContact || '');
      order.status = 'paid_profile_required';
      const token = setupToken(order);
      saveStore();
      return json(res, 200, { verified: true, requiresProfile: true, orderId: order.id, setupToken: token, payer: { email: order.paymentEmail, contact: order.paymentContact } });
    } catch (error) { return json(res, 400, { error: error.message }); }
  }

  if (req.method === 'POST' && url.pathname === '/api/payments/complete-profile') {
    try {
      const data = await readBody(req);
      const order = store.orders[data.orderId];
      if (!order || order.status !== 'paid_profile_required') return json(res, 404, { error: 'Paid order not found or already completed' });
      const tokenHash = crypto.createHash('sha256').update(String(data.setupToken || '')).digest('hex');
      if (!safeEqual(tokenHash, order.setupTokenHash)) return json(res, 401, { error: 'Setup link is invalid or expired' });
      const customer = validateCustomer(data.customer);
      if (order.paymentEmail) customer.email = order.paymentEmail;
      if (order.paymentContact) customer.contact = order.paymentContact;
      const existing = store.users[customer.email];
      if (existing && !verifyPassword(customer.password, existing.passwordHash)) return json(res, 401, { error: 'This email already has an account. Enter its correct password.' });
      order.customer = { name: customer.name, email: customer.email, contact: customer.contact, region: customer.region };
      order.passwordHash = existing?.passwordHash || hashPassword(customer.password);
      order.encryptedPassword = encryptSecret(customer.password);
      order.status = 'paid';
      delete order.setupTokenHash;
      saveStore();
      let provisioning = 'provisioned';
      try { await fulfilOrder(order.id, order.paymentId); } catch { provisioning = 'action_required'; }
      const session = createSession(order.customer.email);
      return json(res, 200, { completed: true, provisioning, redirect: '/dashboard.html' }, { 'Set-Cookie': sessionCookie(session.id) });
    } catch (error) { return json(res, 400, { error: error.message }); }
  }

  if (req.method === 'POST' && url.pathname === '/api/admin/login') {
    try {
      if (!adminLoginAllowed(req)) return json(res, 429, { error: 'Too many login attempts. Try again later.' });
      const credentials = adminCredentials();
      if (!credentials.email || !credentials.password || credentials.password.length < 12) return json(res, 503, { error: 'Admin account is not configured' });
      const data = await readBody(req);
      const email = normalizeEmail(data.email);
      if (!safeEqual(email, credentials.email) || !safeEqual(String(data.password || ''), credentials.password)) return json(res, 401, { error: 'Admin email or password is incorrect' });
      const session = createSession(email, 'admin');
      return json(res, 200, { ok: true, redirect: '/admin.html' }, { 'Set-Cookie': sessionCookie(session.id) });
    } catch (error) { return json(res, 400, { error: error.message }); }
  }

  if (req.method === 'GET' && url.pathname === '/api/admin/overview') {
    const session = requireAdmin(req, res); if (!session) return;
    const orders = Object.values(store.orders).sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
    const servers = Object.values(store.servers).sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
    const users = Object.values(store.users).map(user => ({ name: user.name, email: user.email, createdAt: user.createdAt, servers: servers.filter(server => server.owner === user.email).length }));
    const paidStatuses = new Set(['paid_profile_required', 'paid', 'provisioning', 'provisioned', 'action_required']);
    const revenue = orders.filter(order => paidStatuses.has(order.status)).reduce((total, order) => total + order.cost.total, 0);
    return json(res, 200, {
      admin: { name: process.env.ADMIN_NAME || 'ClarHost Admin', email: session.email },
      csrf: session.csrf,
      panelUrl: panelUrl || null,
      metrics: { customers: users.length, orders: orders.length, servers: servers.length, revenue },
      orders: orders.map(order => ({ id: order.id, customer: order.customer ? { name: order.customer.name, email: order.customer.email } : null, status: order.status, total: order.cost.total, plans: order.cost.selected.map(item => `${item.gameName} ${item.planName}`), paymentId: order.paymentId || null, error: order.provisioningError || null, createdAt: order.createdAt })),
      users,
      servers: servers.map(({ internalId, ...server }) => server)
    });
  }

  const retryMatch = url.pathname.match(/^\/api\/admin\/orders\/([^/]+)\/retry$/);
  if (req.method === 'POST' && retryMatch) {
    const session = requireAdmin(req, res); if (!session || !requireCsrf(req, res, session)) return;
    const order = store.orders[decodeURIComponent(retryMatch[1])];
    if (!order || !order.customer || !order.paymentId) return json(res, 404, { error: 'Paid customer order not found' });
    try { await fulfilOrder(order.id, order.paymentId); return json(res, 200, { retried: true, status: order.status }); }
    catch (error) { return json(res, 502, { error: error.message }); }
  }

  if (req.method === 'POST' && url.pathname === '/api/auth/login') {
    try {
      const data = await readBody(req);
      const email = normalizeEmail(data.email);
      const credentials = adminCredentials();
      if (credentials.email && safeEqual(email, credentials.email)) {
        if (!adminLoginAllowed(req)) return json(res, 429, { error: 'Too many login attempts. Try again later.' });
        if (!safeEqual(String(data.password || ''), credentials.password)) return json(res, 401, { error: 'Email or password is incorrect' });
        const adminSession = createSession(email, 'admin');
        return json(res, 200, { ok: true, role: 'admin', redirect: '/admin.html' }, { 'Set-Cookie': sessionCookie(adminSession.id) });
      }
      const user = store.users[email];
      if (!user || !verifyPassword(String(data.password || ''), user.passwordHash)) return json(res, 401, { error: 'Email or password is incorrect' });
      const session = createSession(email);
      return json(res, 200, { ok: true, redirect: '/dashboard.html' }, { 'Set-Cookie': sessionCookie(session.id) });
    } catch (error) { return json(res, 400, { error: error.message }); }
  }

  if (req.method === 'POST' && url.pathname === '/api/auth/logout') {
    const session = getSession(req);
    if (session) sessions.delete(session.id);
    return json(res, 200, { ok: true }, { 'Set-Cookie': sessionCookie('', true) });
  }

  if (req.method === 'GET' && url.pathname === '/api/account') {
    const session = requireSession(req, res); if (!session) return;
    const user = store.users[session.email];
    return json(res, 200, { user: { name: user.name, email: user.email }, csrf: session.csrf, panelUrl: panelUrl || null });
  }

  if (req.method === 'GET' && url.pathname === '/api/servers') {
    const session = requireSession(req, res); if (!session) return;
    const servers = Object.values(store.servers).filter(server => server.owner === session.email).map(({ owner, internalId, ...server }) => server);
    const orders = Object.values(store.orders).filter(order => order.customer?.email === session.email).map(order => ({ id: order.id, status: order.status, total: order.cost.total, createdAt: order.createdAt, error: order.status === 'action_required' ? 'Automatic setup needs attention' : null }));
    return json(res, 200, { servers, orders });
  }

  const resourceMatch = url.pathname.match(/^\/api\/servers\/([^/]+)\/resources$/);
  if (req.method === 'GET' && resourceMatch) {
    const session = requireSession(req, res); if (!session) return;
    const server = ownedServer(session.email, resourceMatch[1]);
    if (!server) return json(res, 404, { error: 'Server not found' });
    if (demoMode) return json(res, 200, { current_state: 'running', resources: { cpu_absolute: 18.4 + Math.random() * 12, memory_bytes: 1476395008, disk_bytes: 2642411520, network_rx_bytes: 5842012, network_tx_bytes: 2944210 } });
    try { const data = await pteroClient(`/servers/${encodeURIComponent(server.identifier)}/resources`); return json(res, 200, data.attributes || data); }
    catch (error) { return json(res, 502, { error: error.message }); }
  }

  const powerMatch = url.pathname.match(/^\/api\/servers\/([^/]+)\/power$/);
  if (req.method === 'POST' && powerMatch) {
    const session = requireSession(req, res); if (!session || !requireCsrf(req, res, session)) return;
    const server = ownedServer(session.email, powerMatch[1]);
    if (!server) return json(res, 404, { error: 'Server not found' });
    try {
      const data = await readBody(req);
      if (!['start', 'stop', 'restart', 'kill'].includes(data.signal)) return json(res, 400, { error: 'Invalid power action' });
      if (!demoMode) await pteroClient(`/servers/${encodeURIComponent(server.identifier)}/power`, { method: 'POST', body: JSON.stringify({ signal: data.signal }) });
      return json(res, 202, { accepted: true });
    } catch (error) { return json(res, 502, { error: error.message }); }
  }

  return json(res, 404, { error: 'Not found' });
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);

    let fileName = url.pathname === '/' ? 'index.html' : decodeURIComponent(url.pathname.slice(1));
    if (fileName === 'dashboard') fileName = 'dashboard.html';
    if (!publicFiles.has(fileName)) { res.writeHead(404); return res.end('Not found'); }
    const file = path.join(root, fileName);
    if (!fs.existsSync(file)) { res.writeHead(404); return res.end('Not found'); }
    const headers = {
      'Content-Type': mime[path.extname(file)] || 'application/octet-stream',
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'strict-origin-when-cross-origin',
      'X-Frame-Options': 'DENY',
      'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
      'Content-Security-Policy': "default-src 'self'; script-src 'self' https://checkout.razorpay.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; connect-src 'self'; frame-src https://api.razorpay.com https://checkout.razorpay.com https://*.razorpay.com; img-src 'self' data:"
    };
    if (isProduction) headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains';
    res.writeHead(200, headers);
    fs.createReadStream(file).pipe(res);
  } catch (error) {
    if (!res.headersSent) json(res, 500, { error: 'Internal server error' });
    else res.end();
  }
});

server.listen(port, () => console.log(`ClarHost ready on port ${port}`));
// AUTH_HELPERS
// RAZORPAY_HELPERS
// PTERODACTYL_HELPERS
// API_ROUTES
// HTTP_SERVER
