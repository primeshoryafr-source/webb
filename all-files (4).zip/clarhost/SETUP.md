# ClarHost production setup

1. Copy `.env.example` to `.env` and fill every required key. Keep `.env` private. Set `ADMIN_EMAIL` and a unique `ADMIN_PASSWORD` (minimum 12 characters) for `/admin.html`.
2. In Razorpay Live Mode, create an API key and fill `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET`. Set `RAZORPAY_MODE=live` and keep `DEMO_MODE=false`.
3. Enable automatic payment capture. Create a webhook pointing to `https://YOUR-DOMAIN/api/webhooks/razorpay`, subscribe to `payment.captured`, then fill its signing secret as `RAZORPAY_WEBHOOK_SECRET`.
4. In Pterodactyl, create an Application API key with user/server read-write access. Create a Client API key on an admin account that can access the customer servers.
5. Set the Minecraft egg and location IDs so Pterodactyl can choose a free allocation. Configure every other game through `PTERODACTYL_GAME_CONFIG_JSON` before selling it.
6. Run behind HTTPS with `NODE_ENV=production`. The app stores customer/order metadata in `data/store.json`; include this directory in encrypted backups.

After restarting the server, `/api/health` should report `"razorpay":true` and `"razorpayMode":"live"`. Never put the Key Secret or Webhook Secret in `app.js`, HTML, or any public hosting variable.

Run `npm run check`, then `npm start`. Use `DEMO_MODE=true` only for testing: it bypasses real payment and Pterodactyl provisioning.
