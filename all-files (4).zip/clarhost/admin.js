const $ = selector => document.querySelector(selector);
const $$ = selector => [...document.querySelectorAll(selector)];
const money = value => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(value || 0);
const escapeHtml = value => String(value ?? '').replace(/[&<>'"]/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[character]));
let state = null;

async function request(url, options = {}) {
  const response = await fetch(url, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw Object.assign(new Error(data.error || 'Request failed'), { status: response.status });
  return data;
}

function toast(message) {
  const element = $('#toast'); element.textContent = message; element.classList.add('show');
  clearTimeout(toast.timer); toast.timer = setTimeout(() => element.classList.remove('show'), 2600);
}

function badge(status) {
  const warning = ['payment_pending', 'paid_profile_required', 'provisioning'].includes(status);
  const failed = status === 'action_required';
  return `<span class="badge ${warning ? 'warn' : failed ? 'fail' : ''}">${escapeHtml(String(status).replaceAll('_', ' '))}</span>`;
}

function showTab(name) {
  $$('.tab').forEach(panel => panel.classList.toggle('active', panel.dataset.panel === name));
  $$('[data-tab]').forEach(button => button.classList.toggle('active', button.dataset.tab === name && button.closest('nav')));
  $('#pageTitle').textContent = ({ overview: 'Network overview', orders: 'Order management', customers: 'Customer accounts', servers: 'Server inventory' })[name];
}

function render() {
  const { admin, metrics, orders, users, servers } = state;
  $('#adminName').textContent = admin.name; $('#adminEmail').textContent = admin.email;
  $('#adminInitials').textContent = admin.name.split(/\s+/).slice(0, 2).map(word => word[0]).join('').toUpperCase();
  $('#metricRevenue').textContent = money(metrics.revenue); $('#metricCustomers').textContent = metrics.customers;
  $('#metricOrders').textContent = metrics.orders; $('#metricServers').textContent = metrics.servers;
  if (state.panelUrl) { $('#panelLink').href = state.panelUrl; $('#panelLink').hidden = false; }

  $('#recentOrders').innerHTML = orders.slice(0, 6).map(order => `<div class="activity"><div><strong>${escapeHtml(order.plans.join(', '))}</strong><small>${escapeHtml(order.customer?.email || 'Profile pending')} · ${new Date(order.createdAt).toLocaleString('en-IN')}</small></div><span>${money(order.total)}</span></div>`).join('') || '<div class="activity"><small>No orders yet.</small></div>';
  const counts = orders.reduce((result, order) => { result[order.status] = (result[order.status] || 0) + 1; return result; }, {});
  const total = Math.max(orders.length, 1);
  $('#statusBreakdown').innerHTML = Object.entries(counts).map(([status, count]) => `<div class="status-row"><span>${escapeHtml(status.replaceAll('_', ' '))}</span><b>${count}</b><i style="--width:${Math.round(count / total * 100)}%"></i></div>`).join('') || '<div class="status-row"><span>No activity</span><b>0</b><i style="--width:0%"></i></div>';
  renderOrders(orders);
  $('#usersTable').innerHTML = users.map(user => `<tr><td><strong>${escapeHtml(user.name)}</strong></td><td>${escapeHtml(user.email)}</td><td>${user.servers}</td><td>${new Date(user.createdAt).toLocaleDateString('en-IN')}</td></tr>`).join('') || '<tr><td colspan="4">No customers yet.</td></tr>';
  $('#serversGrid').innerHTML = servers.map(server => `<article class="server-card"><span>${escapeHtml(server.identifier)}</span><h3>${escapeHtml(server.name)}</h3><small>${escapeHtml(server.owner)}</small><dl><div><dt>Memory</dt><dd>${Math.round(server.memory / 1024)} GB</dd></div><div><dt>Storage</dt><dd>${Math.round(server.disk / 1024)} GB</dd></div><div><dt>CPU limit</dt><dd>${server.cpu}%</dd></div><div><dt>Created</dt><dd>${new Date(server.createdAt).toLocaleDateString('en-IN')}</dd></div></dl></article>`).join('') || '<article class="server-card"><h3>No servers yet.</h3></article>';
}

function renderOrders(orders) {
  $('#ordersTable').innerHTML = orders.map(order => `<tr><td><strong>${escapeHtml(order.id.slice(-12))}</strong><small>${escapeHtml(order.paymentId || 'Awaiting payment')}</small></td><td><strong>${escapeHtml(order.customer?.name || 'Profile pending')}</strong><small>${escapeHtml(order.customer?.email || '')}</small></td><td>${escapeHtml(order.plans.join(', '))}</td><td><strong>${money(order.total)}</strong></td><td>${badge(order.status)}${order.error ? `<small>${escapeHtml(order.error)}</small>` : ''}</td><td>${new Date(order.createdAt).toLocaleString('en-IN')}</td><td>${order.status === 'action_required' ? `<button class="retry-button" data-retry="${encodeURIComponent(order.id)}">Retry</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="7">No orders yet.</td></tr>';
}

async function loadOverview() {
  state = await request('/api/admin/overview');
  render();
  $('#loginView').hidden = true; $('#adminView').hidden = false;
}

async function boot() {
  try { await loadOverview(); }
  catch (error) { $('#adminView').hidden = true; $('#loginView').hidden = false; if (error.status !== 401) $('#loginError').textContent = error.message; }
}

$('#loginForm').addEventListener('submit', async event => {
  event.preventDefault(); const button = event.currentTarget.querySelector('button'); button.disabled = true; $('#loginError').textContent = '';
  try { await request('/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(Object.fromEntries(new FormData(event.currentTarget))) }); await loadOverview(); }
  catch (error) { $('#loginError').textContent = error.message; }
  finally { button.disabled = false; }
});

document.addEventListener('click', async event => {
  const tab = event.target.closest('[data-tab]'); if (tab) showTab(tab.dataset.tab);
  const retry = event.target.closest('[data-retry]');
  if (retry) { retry.disabled = true; try { await request(`/api/admin/orders/${retry.dataset.retry}/retry`, { method: 'POST', headers: { 'X-CSRF-Token': state.csrf } }); toast('Provisioning retry completed'); await loadOverview(); } catch (error) { toast(error.message); } finally { retry.disabled = false; } }
});

$('#orderSearch').addEventListener('input', event => { const query = event.target.value.trim().toLowerCase(); renderOrders(state.orders.filter(order => JSON.stringify(order).toLowerCase().includes(query))); });
$('#refreshButton').addEventListener('click', async () => { try { await loadOverview(); toast('Admin data refreshed'); } catch (error) { toast(error.message); } });
$('#logoutButton').addEventListener('click', async () => { await request('/api/auth/logout', { method: 'POST' }); location.reload(); });
boot();
