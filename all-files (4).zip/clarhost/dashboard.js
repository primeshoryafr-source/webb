const $ = selector => document.querySelector(selector);
let account = null;
let servers = [];
let selected = null;
let pollTimer = null;

async function request(url, options = {}) {
  const response = await fetch(url, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw Object.assign(new Error(data.error || 'Request failed'), { status: response.status });
  return data;
}

function toast(message) {
  const element = $('#toast');
  element.textContent = message;
  element.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => element.classList.remove('show'), 2800);
}

function bytes(value) {
  const number = Number(value || 0);
  if (number < 1048576) return `${(number / 1024).toFixed(1)} KB`;
  if (number < 1073741824) return `${(number / 1048576).toFixed(1)} MB`;
  return `${(number / 1073741824).toFixed(2)} GB`;
}

function showLogin() {
  $('#appView').hidden = true;
  $('#loginView').hidden = false;
}

function showApp() {
  $('#loginView').hidden = true;
  $('#appView').hidden = false;
  $('#userName').textContent = account.user.name;
  $('#userEmail').textContent = account.user.email;
  $('#userInitials').textContent = account.user.name.split(/\s+/).slice(0, 2).map(part => part[0]).join('').toUpperCase();
  if (account.panelUrl) { $('#fullPanelLink').href = account.panelUrl; $('#fullPanelLink').hidden = false; }
}

async function boot() {
  try {
    account = await request('/api/account');
    showApp();
    await loadServers();
  } catch (error) {
    if (error.status === 401) showLogin();
    else { showLogin(); $('#loginError').textContent = error.message; }
  }
}

async function loadServers() {
  const data = await request('/api/servers');
  servers = data.servers;
  renderOrderNotice(data.orders);
  renderServerNav();
  if (!servers.length) {
    $('#emptyState').hidden = false;
    $('#serverView').hidden = true;
    $('#liveState').innerHTML = '<i></i>No server';
    $('#liveState').classList.add('offline');
    return;
  }
  selectServer(selected?.id || servers[0].id);
}

function renderOrderNotice(orders) {
  const pending = orders.filter(order => order.status !== 'provisioned');
  const notice = $('#orderNotice');
  if (!pending.length) { notice.hidden = true; return; }
  const needsHelp = pending.some(order => order.status === 'action_required');
  notice.hidden = false;
  notice.textContent = needsHelp ? 'Payment received. Automatic server setup needs support attention; your order is safely recorded.' : 'Payment received. Your new server is being provisioned and will appear here automatically.';
}

function renderServerNav() {
  const nav = $('#serverNav');
  nav.textContent = '';
  servers.forEach(server => {
    const button = document.createElement('button');
    button.type = 'button';
    if (server.id === selected?.id) button.classList.add('active');
    const name = document.createElement('span'); name.textContent = server.name;
    const code = document.createElement('small'); code.textContent = server.identifier;
    button.append(name, code);
    button.addEventListener('click', () => selectServer(server.id));
    nav.append(button);
  });
}

function selectServer(id) {
  selected = servers.find(server => server.id === id) || servers[0];
  $('#emptyState').hidden = true;
  $('#serverView').hidden = false;
  $('#serverName').textContent = selected.name;
  $('#serverCode').textContent = selected.identifier;
  $('#gameValue').textContent = selected.gameId.toUpperCase();
  $('#identifierValue').textContent = selected.identifier;
  $('#planValue').textContent = `${Math.round(selected.memory / 1024)} GB`;
  $('#createdValue').textContent = new Date(selected.createdAt).toLocaleDateString('en-IN', { dateStyle: 'medium' });
  renderServerNav();
  clearInterval(pollTimer);
  refreshResources();
  pollTimer = setInterval(refreshResources, 10000);
  $('.sidebar').classList.remove('open');
}

async function refreshResources() {
  if (!selected) return;
  const serverId = selected.id;
  try {
    const data = await request(`/api/servers/${encodeURIComponent(serverId)}/resources`);
    if (selected.id !== serverId) return;
    const resource = data.resources || {};
    const cpu = Number(resource.cpu_absolute || 0);
    const memoryPercent = Math.min(100, Number(resource.memory_bytes || 0) / (selected.memory * 1048576) * 100);
    const diskPercent = Math.min(100, Number(resource.disk_bytes || 0) / (selected.disk * 1048576) * 100);
    $('#cpuValue').textContent = `${cpu.toFixed(1)}%`;
    $('#memoryValue').textContent = bytes(resource.memory_bytes);
    $('#diskValue').textContent = bytes(resource.disk_bytes);
    $('#networkValue').textContent = bytes(Number(resource.network_rx_bytes || 0) + Number(resource.network_tx_bytes || 0));
    $('#cpuBar').style.width = `${Math.min(100, cpu)}%`;
    $('#memoryBar').style.width = `${memoryPercent}%`;
    $('#diskBar').style.width = `${diskPercent}%`;
    const running = data.current_state === 'running';
    $('#liveState').innerHTML = `<i></i>${running ? 'Online' : (data.current_state || 'Offline')}`;
    $('#liveState').classList.toggle('offline', !running);
  } catch (error) {
    $('#liveState').innerHTML = '<i></i>Unavailable';
    $('#liveState').classList.add('offline');
  }
}

async function sendPower(signal, button) {
  if (!selected || (signal === 'kill' && !window.confirm('Force shutdown this server?'))) return;
  const buttons = [...document.querySelectorAll('[data-power]')];
  buttons.forEach(item => item.disabled = true);
  try {
    await request(`/api/servers/${encodeURIComponent(selected.id)}/power`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': account.csrf }, body: JSON.stringify({ signal }) });
    toast(`${signal[0].toUpperCase()}${signal.slice(1)} command accepted`);
    setTimeout(refreshResources, 1200);
  } catch (error) { toast(error.message); }
  finally { buttons.forEach(item => item.disabled = false); }
}

$('#loginForm').addEventListener('submit', async event => {
  event.preventDefault();
  const button = event.currentTarget.querySelector('button');
  button.disabled = true;
  $('#loginError').textContent = '';
  try {
    const result = await request('/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(Object.fromEntries(new FormData(event.currentTarget))) });
    if (result.role === 'admin') window.location.assign(result.redirect || '/admin.html');
    else await boot();
  } catch (error) { $('#loginError').textContent = error.message; }
  finally { button.disabled = false; }
});

$('#logoutButton').addEventListener('click', async () => { await request('/api/auth/logout', { method: 'POST' }); location.reload(); });
$('#menuButton').addEventListener('click', () => $('.sidebar').classList.toggle('open'));
document.querySelectorAll('[data-power]').forEach(button => button.addEventListener('click', () => sendPower(button.dataset.power, button)));
boot();
