const buildPlans = (gameId, definitions) => definitions.map(([slug,planName,price,ram,disk,slots,cpu,recommended=false]) => ({id:`${gameId}-${slug}`,planName,price,ram,disk,slots,cpu,recommended}));
const products = [
  {id:'minecraft',name:'Minecraft',type:'sandbox',tag:'BESTSELLER',icon:'MC',banner:'assets/banners/minecraft.webp',bg:'#526a45',accent:'#8db05f',plans:buildPlans('minecraft',[['2gb','Starter',199,2,10,20,100],['4gb','Standard',399,4,20,40,150,true],['8gb','Pro',699,8,40,80,250],['16gb','Community',1299,16,80,160,400]])},
  {id:'rust',name:'Rust',type:'survival',tag:'POPULAR',icon:'R',banner:'assets/banners/rust.webp',bg:'#73372d',accent:'#b44d36',plans:buildPlans('rust',[['6gb','Starter',599,6,30,40,200],['8gb','Standard',749,8,40,60,250,true],['12gb','Pro',999,12,60,100,350],['16gb','Community',1399,16,80,150,450]])},
  {id:'cs2',name:'Counter-Strike 2',type:'fps',tag:'240 TICK',icon:'C2',banner:'assets/banners/cs2.webp',bg:'#2e4654',accent:'#e29f32',plans:buildPlans('cs2',[['4gb','Starter',549,4,20,12,180],['6gb','Competitive',699,6,30,20,250,true],['8gb','Pro',849,8,40,32,350],['12gb','Tournament',1199,12,60,64,500]])},
  {id:'ark',name:'ARK: Survival',type:'survival',tag:'CLUSTER READY',icon:'A',banner:'assets/banners/ark.webp',bg:'#254d4e',accent:'#38a7a0',plans:buildPlans('ark',[['8gb','Starter',749,8,40,20,250],['12gb','Standard',999,12,60,40,350,true],['16gb','Cluster',1299,16,80,70,450],['24gb','Ascendant',1799,24,120,100,600]])},
  {id:'palworld',name:'Palworld',type:'survival',tag:'TRENDING',icon:'PW',banner:'assets/banners/palworld.webp',bg:'#48536c',accent:'#6ca6ca',plans:buildPlans('palworld',[['8gb','Starter',699,8,30,12,250],['12gb','Standard',949,12,50,24,350,true],['16gb','Pro',1199,16,70,32,450],['24gb','Guild',1699,24,100,48,600]])},
  {id:'valheim',name:'Valheim',type:'sandbox',tag:'MOD READY',icon:'V',banner:'assets/banners/valheim.webp',bg:'#414546',accent:'#a39165',plans:buildPlans('valheim',[['2gb','Starter',199,2,10,5,100],['4gb','Standard',349,4,20,10,150,true],['8gb','Clan',599,8,40,20,250],['12gb','Community',849,12,60,40,350]])}
];
const allPlans=products.flatMap(game=>game.plans.map(plan=>({...plan,gameId:game.id,name:game.name,icon:game.icon,bg:game.bg,accent:game.accent,ramLabel:`${plan.ram} GB RAM`,slotsLabel:`${plan.slots} slots`})));

const $ = (s,root=document) => root.querySelector(s);
const $$ = (s,root=document) => [...root.querySelectorAll(s)];
const money = n => new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:0}).format(n);
let cart = JSON.parse(localStorage.getItem('clarhost-cart') || '[]').map(saved=>allPlans.find(plan=>plan.id===saved.id)).filter(Boolean);
let pendingSetup = JSON.parse(sessionStorage.getItem('clarhost-paid-setup') || 'null');

function renderGames(filter='all'){
  const list = filter === 'all' ? products : products.filter(p => p.type === filter);
  $('#gameGrid').innerHTML = list.map(p => `
    <article class="game-card" data-type="${p.type}">
      <div class="game-art has-banner" style="--card-bg:${p.bg};--card-accent:${p.accent}"><img class="game-banner" src="${p.banner}" alt="${p.name} server banner artwork" loading="lazy" decoding="async"><span class="game-badge">${p.tag}</span></div>
      <div class="game-body"><div class="game-title-row"><h3>${p.name}</h3><span>IN STOCK</span></div>
      <div class="game-specs"><span>${p.plans[0].ram}–${p.plans.at(-1).ram} GB RAM</span><span>${p.plans.length} plans</span></div>
      <div class="game-buy"><div class="price"><small>STARTING AT</small><strong>${money(p.plans[0].price)}<span>/mo</span></strong></div><button class="add-button" data-plans="${p.id}" aria-label="View ${p.name} plans">→</button></div></div>
    </article>`).join('');
}

function persist(){localStorage.setItem('clarhost-cart',JSON.stringify(cart));renderCart()}
function addToCart(id){
  if(cart.some(i => i.id === id)){toast('Already equipped','This server is already in your cart.');openCart();return}
  const selected=allPlans.find(plan=>plan.id===id);if(!selected)return;
  cart.push(selected);persist();toast('Added to loadout',`${selected.name} ${selected.planName} added.`);if($('#planModal').open)$('#planModal').close();openCart();
}
function openPlans(id){
  const game=products.find(product=>product.id===id);if(!game)return;
  $('#planGameName').textContent=game.name;$('#planGameMeta').textContent=`${game.plans.length} configurations · Instant deployment`;
  $('#planHero').style.backgroundImage=`linear-gradient(90deg,rgba(7,9,8,.92),rgba(7,9,8,.25)),url('${game.banner}')`;
  $('#planGrid').innerHTML=game.plans.map(plan=>`<article class="plan-card ${plan.recommended?'recommended':''}">${plan.recommended?'<span class="recommend-tag">MOST POPULAR</span>':''}<small>${plan.planName.toUpperCase()}</small><h3>${plan.ram}<span>GB</span></h3><div class="plan-price"><strong>${money(plan.price)}</strong><span>/ month</span></div><ul><li><b>${plan.cpu}%</b> CPU limit</li><li><b>${plan.ram} GB</b> DDR4 memory</li><li><b>${plan.disk} GB</b> NVMe storage</li><li><b>${plan.slots}</b> player slots</li><li>Automated backups</li></ul><button data-add="${plan.id}">Choose ${plan.planName} <span>→</span></button></article>`).join('');
  openDialog('planModal');
}
function removeFromCart(id){cart=cart.filter(i=>i.id!==id);persist()}
function totals(){const subtotal=cart.reduce((n,p)=>n+p.price,0);return{subtotal,tax:Math.round(subtotal*.18),total:Math.round(subtotal*1.18)}}
function renderCart(){
  const {subtotal,tax,total}=totals();
  $('#cartCount').textContent=cart.length;$('#drawerCount').textContent=cart.length;
  $('#cartItems').innerHTML=cart.map(p=>`<div class="cart-row"><div class="cart-thumb" style="--thumb:${p.bg}">${p.icon}</div><div><h4>${p.name} · ${p.planName}</h4><p>${p.ramLabel} · ${p.slotsLabel} · Monthly</p></div><div><strong>${money(p.price)}</strong><button class="remove-item" data-remove="${p.id}">Remove</button></div></div>`).join('');
  $('#subtotal').textContent=money(subtotal);$('#tax').textContent=money(tax);$('#total').textContent=money(total);
  $('#cartEmpty').classList.toggle('show',!cart.length);$('#cartSummary').style.display=cart.length?'block':'none';
}
function openCart(){ $('#cartDrawer').classList.add('open');$('#cartDrawer').setAttribute('aria-hidden','false');$('#drawerBackdrop').classList.add('show');document.body.style.overflow='hidden'}
function closeCart(){ $('#cartDrawer').classList.remove('open');$('#cartDrawer').setAttribute('aria-hidden','true');$('#drawerBackdrop').classList.remove('show');document.body.style.overflow=''}
function toast(title,msg){const el=document.createElement('div');el.className='toast';el.innerHTML=`<strong>${title}</strong>${msg}`;$('#toastRegion').append(el);setTimeout(()=>el.remove(),3600)}
function openDialog(id){const d=$(`#${id}`);if(!d.open)d.showModal()}
function loadRazorpay(){return new Promise((resolve,reject)=>{if(window.Razorpay)return resolve();const s=document.createElement('script');const timeout=setTimeout(()=>reject(new Error('Razorpay checkout timed out. Check network or ad-blocker.')),12000);s.src='https://checkout.razorpay.com/v1/checkout.js';s.onload=()=>{clearTimeout(timeout);resolve()};s.onerror=()=>{clearTimeout(timeout);reject(new Error('Razorpay checkout could not load. Disable ad-blocker and retry.'))};document.head.appendChild(s)})}

async function beginCheckout(){
  if(pendingSetup){openDialog('checkoutModal');return}
  const button=$('#checkoutButton');const original=button.innerHTML;button.disabled=true;button.textContent='Opening Razorpay…';
  try{
    const response=await fetch('/api/payments/order',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({items:cart.map(i=>i.id)})});
    const order=await response.json();
    if(!response.ok)throw new Error(order.error||'Order could not be created');
    if(order.mode==='demo'){
      button.textContent='Confirming demo payment…';
      await completePayment({razorpay_order_id:order.order_id,razorpay_payment_id:'demo_payment'});
      return;
    }
    await loadRazorpay();
    const rz=new Razorpay({key:order.key_id,amount:order.amount,currency:'INR',name:'ClarHost',description:`${cart.length} game server plan${cart.length===1?'':'s'}`,order_id:order.order_id,theme:{color:'#0a0b0b'},retry:{enabled:true,max_count:2},remember_customer:false,modal:{confirm_close:true,ondismiss:()=>toast('Payment cancelled','Your cart is saved. No charge was made.')},handler:async payment=>{
      try{await completePayment(payment)}catch(error){toast('Verification failed',error.message||'Please contact support with your payment ID.')}
    }});rz.on('payment.failed',response=>toast('Payment failed',response?.error?.description||'No charge was completed. Please try again.'));rz.open();
  }catch(err){toast('Checkout unavailable',err.message || 'Please try again.')}finally{button.disabled=false;button.innerHTML=original}
}
async function completePayment(payment){
  const response=await fetch('/api/payments/verify',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payment)});
  const result=await response.json();
  if(!response.ok)throw new Error(result.error||'Payment verification failed');
  pendingSetup={orderId:result.orderId,setupToken:result.setupToken,payer:result.payer||{}};
  sessionStorage.setItem('clarhost-paid-setup',JSON.stringify(pendingSetup));
  const form=$('#checkoutForm');
  if(pendingSetup.payer.email)form.elements.email.value=pendingSetup.payer.email;
  if(pendingSetup.payer.contact)form.elements.contact.value=pendingSetup.payer.contact;
  toast('Payment confirmed','Complete account setup to deploy your server.');
  openDialog('checkoutModal');
}
async function completeProfile(customer){
  if(!pendingSetup)throw new Error('Paid order setup was not found');
  const response=await fetch('/api/payments/complete-profile',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({orderId:pendingSetup.orderId,setupToken:pendingSetup.setupToken,customer})});
  const result=await response.json();
  if(!response.ok)throw new Error(result.error||'Account setup failed');
  sessionStorage.removeItem('clarhost-paid-setup');pendingSetup=null;cart=[];persist();
  window.location.assign(result.redirect||'/dashboard.html');
}

renderGames();renderCart();
document.addEventListener('click',e=>{
  const plans=e.target.closest('[data-plans]');if(plans)openPlans(plans.dataset.plans);
  const add=e.target.closest('[data-add]');if(add)addToCart(add.dataset.add);
  const remove=e.target.closest('[data-remove]');if(remove)removeFromCart(remove.dataset.remove);
  const filter=e.target.closest('.filter');if(filter){$$('.filter').forEach(b=>b.classList.remove('active'));filter.classList.add('active');renderGames(filter.dataset.filter)}
  const close=e.target.closest('[data-close]');if(close)$(`#${close.dataset.close}`).close();
  if(e.target.closest('.open-panel'))openDialog('panelModal');
});
$('#cartOpen').addEventListener('click',openCart);$('#cartClose').addEventListener('click',closeCart);$('#drawerBackdrop').addEventListener('click',closeCart);
$('#browseServers').addEventListener('click',()=>{closeCart();$('#games').scrollIntoView({behavior:'smooth'})});
$('#checkoutButton').addEventListener('click',()=>{closeCart();beginCheckout()});
$('#checkoutForm').addEventListener('submit',async e=>{e.preventDefault();const button=$('#payButton');const original=button.innerHTML;button.disabled=true;button.textContent='Deploying server…';try{await completeProfile(Object.fromEntries(new FormData(e.currentTarget)))}catch(error){toast('Setup failed',error.message)}finally{button.disabled=false;button.innerHTML=original}});
$('#commandForm').addEventListener('submit',e=>{e.preventDefault();const input=$('#commandInput');if(!input.value.trim())return;const p=document.createElement('p');p.innerHTML=`<span>${new Date().toLocaleTimeString('en-GB')}</span> &gt; ${input.value.replace(/[<>]/g,'')}`;$('#demoLogs').append(p);$('#demoLogs').scrollTop=$('#demoLogs').scrollHeight;input.value=''});
$$('[data-action]').forEach(b=>b.addEventListener('click',()=>{const state=$('#serverState');if(b.dataset.action==='stop'){state.innerHTML='<i style="background:#ff6969"></i> Stopped';b.textContent='Start';b.dataset.action='start';toast('Server stopped','The demo server is now offline.')}else if(b.dataset.action==='start'){state.innerHTML='<i></i> Running';b.textContent='Stop';b.dataset.action='stop';toast('Server online','The demo server is accepting connections.')}else{state.innerHTML='<i style="background:#f4b740"></i> Restarting';setTimeout(()=>{state.innerHTML='<i></i> Running';toast('Restart complete','Server is back online.')},1200)}}));
setInterval(()=>{const el=$('#demoCpu');if(el)el.textContent=(18+Math.random()*14).toFixed(1)+'%'},2400);
